Using python 3.10.12
Install requirements using pip install -r requirements.txt
